/*****************************
 * for assigning vector y <- x
 *****************************/

void assign_vec(double *x, double *y, int n)
{
  int i;
  for (i=0; i<n; i++){
    y[i] = x[i];
  }
  return;
}

/************************************
 * for doing t(X) %*% diag(1/b) %*% X
 ************************************/

void mat_prod_tXaX(double *X, double b, double *tXaX, int m, int n)
// t(X)%*%diag(1/b)%*%X
// X is m*n
{
  int i, j, k;
  for (i=0; i<n; i++){
    for (j=0; j<n; j++){
      tXaX[i + n*j] = 0;
      for (k=0; k<m; k++){
        tXaX[i + n*j] += X[k + m*i] * X[k + m*j];
      }
      tXaX[i + n*j] = tXaX[i + n*j]/b;
    }
  }
  return;
}

/***************************************
 * vectorized version of bessel function 
 ***************************************/

void bessel_i_vec(double *x, double *out, double nu, double expo, int n)
/* out is the container of the output */
{
  int i;
  for (i=0; i<n; i++){
    out[i] = bessel_i(x[i], nu, expo); //note expo can only be 1 or 2
  }
  return;
}

/************************************
 *
 ***********************************/

double max_abs_diff(double *x, double *y, int n)
{
  int i;
  double out, temp;
  out = fabs(x[0]-y[0]);
  for (i=1; i<n; i++){
    temp = fabs(x[i]-y[i]);
    if (temp>out){
      out = temp;
    }
  }
  return out;
}

/***********************************************
 * modified bessel function to cope with large x
 ***********************************************/
// ref: R package Besssel:::besselIasym
// ref: R function bessel
// expo can only be 1 or 2

double besselIm(double x, double nu, double expo, double thres)
{
  if (x<=thres){
    // small x case
    return bessel_i(x, nu, expo);
  } else {
    // large x case: asymptotic expansion
    int k;
    double d, x8;

    d = 0.0;
    x8 = x*8.0;

    for (k = 10; k > 0; --k) // k.max is set to be 10
    {
      d = (1.0 - d) * ((2.0 * (nu - k) + 1.0) * (2.0 * (nu + k) - 1.0))/(k * x8);
    }

    if (expo>1.0){
      return (1.0 - d ) /sqrt(2.0 * M_PI * x);
    } else {
      return (exp(x) * (1.0 - d))/sqrt(2.0 * M_PI * x);
    }
  }
}

/**************************************************
 * vectorized version of bessel function (modified)
 **************************************************/

void besselIm_vec(double *x, double *out, double nu, double expo, double thres, int n)
/* out is the container of the output */
{
  int i;
  for (i=0; i<n; i++){
    out[i] = besselIm(x[i], nu, expo, thres); //note expo can only be 1 or 2
  }
  return;
}

