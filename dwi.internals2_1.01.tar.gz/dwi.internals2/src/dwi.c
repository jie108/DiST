#include <R.h>
#include <Rinternals.h>
#include <Rmath.h>
#include "dwi.h"
#define THRESH 100000

/**********************
 *  L1 fit
 **********************/

SEXP dwi_fit_l1_internal_C(SEXP Rlasso_lam, SEXP Rbetas0, SEXP Ry, SEXP RS,
    SEXP Rgam, SEXP Rbetas_w, SEXP Rsigma, SEXP RNmiddle_max, SEXP
    RNinner, SEXP Rtol, SEXP Rbeta_max)
{
  /* Digest the datastructures (SEXPs) from R */
  int Nmiddle_max, Ninner;
  double lasso_lam, *betas0, *y, *S, gam, *betas_w, sigma, tol, beta_max;

  lasso_lam = REAL(coerceVector(Rlasso_lam,REALSXP))[0];
  betas0 = REAL(coerceVector(Rbetas0,REALSXP));
  y = REAL(coerceVector(Ry,REALSXP));
  S = REAL(coerceVector(RS,REALSXP));
  gam = REAL(coerceVector(Rgam,REALSXP))[0];
  betas_w = REAL(coerceVector(Rbetas_w,REALSXP));
  sigma = REAL(coerceVector(Rsigma,REALSXP))[0];
  Nmiddle_max = INTEGER(coerceVector(RNmiddle_max,INTSXP))[0];
  Ninner = INTEGER(coerceVector(RNinner,INTSXP))[0];
  tol = REAL(coerceVector(Rtol, REALSXP))[0];
  beta_max = REAL(coerceVector(Rbeta_max,REALSXP))[0];


  /* main */
  int n, p, count, i, j, ii;
  double mdiff, sigma2;

  n = INTEGER(getAttrib(RS, R_DimSymbol))[0];
  p = INTEGER(getAttrib(RS, R_DimSymbol))[1];

  double betas[p], betas1[p], temp, temp2, temp3, a1[n], Aw_sumi[p],
         Bw_sumi[p*p], denom[p], fitrss[p], betaj;

  mdiff = tol+1.0;
  count = 1;
  sigma2 = sigma*sigma;
  assign_vec(betas0, betas, p);

  while ((mdiff > tol) && (count <= Nmiddle_max)){
    assign_vec(betas, betas1, p);

    // middle loop
    //mat_vec_prod(S, betas, temp, n, p);
    //vec_div(temp, sigma2);

    for (i=0; i<n; i++){
      // compute temp
      temp = 0;
      for (j=0; j<p; j++){
        temp += S[i + j*n] * betas[j];
      }
      temp = temp/sigma2;

      temp2 = temp*y[i];
      //temp3 = -temp + bessel_i(temp2, 1.0, 2.0)/bessel_i(temp2, 0.0, 2.0)*y[i]/sigma2;
      temp3 = -temp + besselIm(temp2, 1.0, 2.0, THRESH)/besselIm(temp2, 0.0, 2.0, THRESH)*y[i]/sigma2;
      a1[i] =  temp3;
    }

    // to get Aw_sumi
    for (j=0; j<p; j++){
      Aw_sumi[j] = 0;
      for (i=0; i<n; i++){
        Aw_sumi[j] += a1[i] * S[i+j*n];
      }
    }

    mat_prod_tXaX(S, sigma2, Bw_sumi, n, p);

    for (j=0; j<p; j++){
      denom[j] = Bw_sumi[j + j*p]/n;
    }

    for (j=0; j<p; j++){
      fitrss[j] = Aw_sumi[j]/n;
    }

    for (ii=0; ii<Ninner; ii++){
      for (j=0; j<p; j++){
        betaj = betas[j];
        betas[j] = fmin(fmax(0.0, (fitrss[j]+betas[j]*denom[j]-gam*betas_w[j]-lasso_lam)/denom[j]),beta_max);
        for (i=0; i<p; i++){
          fitrss[i] = fitrss[i] - (betas[j]-betaj)*Bw_sumi[i+j*p]/n;
        }
      }
    }
    mdiff = max_abs_diff(betas, betas1, p);
    count += 1;
  }

  /* Create SEXP to hold the answer */
  SEXP Rbetas;
  PROTECT(Rbetas = allocVector(REALSXP, p));
  assign_vec(betas, REAL(Rbetas), p);

  UNPROTECT(1);
  return Rbetas;
}

/************************
 * ArrayIndex
 ***********************/

SEXP ArrayIndex_C(SEXP Rdims, SEXP Rxrange, SEXP Ryrange, SEXP Rzrange)
{
  /* Digest the datastructures (SEXPs) from R */
  int *dims, *xrange, *yrange, *zrange, xlen, ylen, zlen, len;
  dims = INTEGER(coerceVector(Rdims, INTSXP));
  xrange = INTEGER(coerceVector(Rxrange, INTSXP));
  yrange = INTEGER(coerceVector(Ryrange, INTSXP));
  zrange = INTEGER(coerceVector(Rzrange, INTSXP));
  xlen = length(Rxrange);
  ylen = length(Ryrange);
  zlen = length(Rzrange);
  len = xlen*ylen*zlen;

  /* main */
  int i, j, k, count, *indexlist;
  SEXP Rindexlist;
  PROTECT(Rindexlist = allocVector(INTSXP, len));
  indexlist = INTEGER(Rindexlist);

  count = 0;
  for (k = 0; k < zlen; ++k)
  {
    for (j = 0; j < ylen; ++j)
    {
      for (i = 0; i < xlen; ++i)
      {
        indexlist[count] = (zrange[k]-1)*dims[0]*dims[1] + (yrange[j]-1)*dims[0] + xrange[i];
        count += 1;
      }
    }
  }

  UNPROTECT(1);
  return Rindexlist;
}


/**********************
 * bessel function
 *********************/
// for testing purpose

SEXP mybessel_C(SEXP Rx, SEXP Rnu, SEXP Rexpon, SEXP Rthres)
{

  /* Digest the datastructures (SEXPs) from R */
  double x, expon, nu, thres;

  x = REAL(coerceVector(Rx, REALSXP))[0];
  nu = REAL(coerceVector(Rnu, REALSXP))[0];
  expon = REAL(coerceVector(Rexpon, REALSXP))[0];
  thres = REAL(coerceVector(Rthres, REALSXP))[0];

  /* Main */
  SEXP Rout;
  PROTECT(Rout = allocVector(REALSXP, 1));
  REAL(Rout)[0] = besselIm(x, nu, expon+1.0, thres);

  UNPROTECT(1);
  return Rout;
}

