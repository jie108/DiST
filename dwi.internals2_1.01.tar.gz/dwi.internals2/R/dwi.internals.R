#### wrapper function of dwi.fit.l1.internal_C ####
dwi.fit.l1.internal <- function(lasso.lam, betas0, y, S, gam, betas.w,
                                sigma, Nmiddle.max=100, Ninner=25, tol=1e-8,
                                beta.max=10)
{
  betas <- .Call("dwi_fit_l1_internal_C", lasso.lam, betas0, y, S, gam,
                 betas.w, sigma, Nmiddle.max, Ninner, tol, beta.max,
                 PACKAGE="dwi.internals2")
  return(list(betas=betas,df=sum(betas!=0),gam=gam,betas.w=betas.w))
}

#### wrapper function of ArrayIndex_C ####
ArrayIndex <- function(dims, xrange, yrange, zrange)
{
  return(.Call("ArrayIndex_C", dims, xrange, yrange, zrange, PACKAGE="dwi.internals2"))
}

#### wrapper function of mybessel_C ####
mybessel <- function(x, nu, expon.scaled=FALSE, thres=100000)
{
  return(.Call("mybessel_C", x, nu, as.numeric(expon.scaled), thres, PACKAGE="dwi.internals2"))
}

         
